// lib/resident/features/home/widgets/home_header.dart

import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:http/http.dart' as http;
import '../../../core/app_config.dart';

class HomeHeader extends StatefulWidget {
  final VoidCallback? onNotificationTap;
  final bool hasNotification;

  const HomeHeader({
    super.key,
    this.onNotificationTap,
    this.hasNotification = false,
  });

  @override
  State<HomeHeader> createState() => _HomeHeaderState();
}

class _HomeHeaderState extends State<HomeHeader> {
  Map<String, dynamic>? _userData;

  @override
  void initState() {
    super.initState();
    _fetchUser();
  }

  Future<void> _fetchUser() async {
    try {
      final uid = FirebaseAuth.instance.currentUser?.uid;
      if (uid == null) return;
      final res = await http.get(Uri.parse('${AppConfig.baseUrl}/users/$uid'));
      if (res.statusCode == 200 && mounted) {
        setState(() => _userData = jsonDecode(res.body));
      }
    } catch (_) {}
  }

  String get _firstName {
    final fn = _userData?['first_name'] as String? ?? '';
    return fn.isNotEmpty
        ? fn
        : (FirebaseAuth.instance.currentUser?.displayName ?? '');
  }

  String get _initial {
    final name = _firstName.trim();
    return name.isNotEmpty ? name[0].toUpperCase() : '?';
  }

  String? get _imageUrl => _userData?['image_url'] as String?;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 20, right: 16, top: 60, bottom: 10),
      child: Row(
        children: [
          // ── Avatar ────────────────────────────────────────────────────
          _buildAvatar(),
          const SizedBox(width: 14),

          // ── Text ──────────────────────────────────────────────────────
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Smart Niti',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                    color: Color(0xFF0F172A),
                    letterSpacing: -0.3,
                  ),
                ),
                const SizedBox(height: 1),
                RichText(
                  text: TextSpan(
                    style: const TextStyle(
                      fontSize: 13,
                      color: Color(0xFF64748B),
                    ),
                    children: [
                      const TextSpan(text: 'Welcome, '),
                      TextSpan(
                        text: _firstName.isNotEmpty ? _firstName : '...',
                        style: const TextStyle(
                          fontWeight: FontWeight.w700,
                          color: Color(0xFF137FEC),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // ── Notification button ───────────────────────────────────────
          Stack(
            clipBehavior: Clip.none,
            children: [
              Container(
                width: 42,
                height: 50,
                decoration: BoxDecoration(
                  color: Colors.white,
                  border: Border.all(color: const Color(0xFFF1F5F9), width: 1),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: IconButton(
                  icon: const Icon(Icons.notifications_outlined),
                  onPressed: widget.onNotificationTap,
                  iconSize: 24,
                  padding: EdgeInsets.zero,
                  color: const Color(0xFF334155),
                ),
              ),
              if (widget.hasNotification)
                Positioned(
                  right: 8,
                  top: 8,
                  child: Container(
                    width: 9,
                    height: 9,
                    decoration: BoxDecoration(
                      color: Colors.red,
                      shape: BoxShape.circle,
                      border: Border.all(color: Colors.white, width: 2),
                    ),
                  ),
                ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildAvatar() {
    final url = _imageUrl;
    return Container(
      width: 46,
      height: 46,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        border: Border.all(color: const Color(0xFF137FEC), width: 2),
      ),
      child: ClipOval(
        child: (url != null && url.isNotEmpty)
            ? Image.network(
                url,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => _initialAvatar(),
              )
            : _initialAvatar(),
      ),
    );
  }

  Widget _initialAvatar() {
    return Container(
      color: const Color(0xFFDBEAFE),
      alignment: Alignment.center,
      child: Text(
        _initial,
        style: const TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.w800,
          color: Color(0xFF137FEC),
        ),
      ),
    );
  }
}
